Extract contents (all in the same directory) and run Bugs.exe. Read instructions in window for controls. You may need to place the DLL files in your windows/system32 directory. Source file is balj3289.cpp . 'Screen_Saver.scr' is a slightly modified version that acts as a screen saver.

