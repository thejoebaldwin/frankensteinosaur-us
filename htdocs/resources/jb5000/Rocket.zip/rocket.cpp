  
//By Joe Baldwin
//Program3.cpp
//balj3289
//CS 459
// ********************************************************
// program3.cpp by Joe Baldwin
// Extra: All curved surfaces have blended normals
// Extra: blended normals can be toggled on/off with right mouse click
// Extra: Ride is raised and lowered with 3 Pistons 
//  uses double buffering for smooth animation
// Left mouse click ---------- Start Rocket Ride
// Middle Mouse click -------- Stop Rocket Ride
// Right Mouse click --------- Extra: Toggle normal blending for each face
// a, A, b, B, c, C ---------- change light source position
// x, X, y, Y, z, Z ---------- change viewer position
// 1, 2, 3, 4, 5, 6 ---------- change to preset viewer positions
// ESC ----------------------- exit
// **********************************************************
//Adopted from code --->
/* boxontable8.c */ 

/* 
 *  By Ichiro Suzuki. Parts of this program might have been adopted 
 *  from or inspired by sample programs in "OpenGL Programming Guide", 
 *  Copyright (c) 1993-1997, Silicon Graphics, Inc.
 */

/*  
 *  - extension of boxontable7.c
 *  - viewer position is controlled by "x", "X", "y", "Y", "z", "Z"
 */

#include <GL/glut.h>
#include <math.h>
#include <stdio.h>
#include <iostream>


#define PI 3.14159265

using namespace std;
static GLfloat deg = 0.0;
static GLfloat deg2 = 0.0;
static bool expand = true;
static bool contract = false;
bool smoothNormals = true;
static int timer =0;
static GLfloat inkr = 0.1;
class vek{
public:
     GLfloat x;
	 GLfloat y;
	 GLfloat z;
	 };
class plane{
public:
     vek a;
	 vek b;
	 vek c;
	 vek d;
	 vek normal;
	 void makeNorm();
	 vek aNorm;
	 vek bNorm;
	 vek cNorm;
	 vek dNorm;
     };
static int window1;
static int window2;
int rideLimit = 0;
int rideTimer = 0;
GLuint theFloor;
GLuint theFence;
bool is_raise = false;

static GLdouble observer[] = {0.0, 2.0, 3.0};
float lightAngle = 90.0;
int time = 0;
float rAngle2;
float increment;
bool armAngleDone = false;
bool pAngleDone = false;
bool rAngleDone = false;
bool rAngle2Done = false;



static int object_row = 0;
static int object_col = 0;
static len = 7.5;
bool transp = false;
GLfloat LastNorm[3];
static int stepsize = 60;
static GLfloat step[]= {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                       0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                       0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
static GLfloat vert[] ={0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                       0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                       0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};

GLfloat lightColor[] = {0.0, 1.0, 0.0, 1.0};
/* vectors to specify material properties */ 
static GLfloat extreme[] = {200.0};
static GLfloat high[]  = {100.0}; /* for shininess */
static GLfloat low[]  = {25.0}; /* for shininess */
static GLfloat medium[]  = {50.0}; /* for shininess */
static GLfloat none[]    = {0.0, 0.0, 0.0, 1.0};
static GLfloat white[]   = {1.0, 1.0, 1.0, 1.0};
static GLfloat off_white[]= {0.8, 0.8, 0.8, 1.0};
static GLfloat gray[]    = {0.5, 0.5, 0.5, 1.0};
static GLfloat orange[]  = {1.0, 0.5, 0.0, 0.5};
static GLfloat red[]     = {1.0, 0.0, 0.0, 1.0};
static GLfloat green[]   = {0.0, 1.0, 0.0, 1.0};
static GLfloat blue[]    = {0.0, 0.0, 1.0, 1.0};
static GLfloat yellow[]  = {1.0, 1.0, 0.0, 1.0}; 
static GLfloat magenta[] = {1.0, 0.0, 1.0, 1.0}; 
static GLfloat cyan[]    = {0.0, 1.0, 1.0, 1.0}; 
static GLfloat cyan_dull[]= {0.0, 0.4, 0.4, 1.0}; 
static GLfloat black[]= {0.0, 0.0, 0.0, 0.0}; 

static int light = 0;
/* position of light source */
static GLfloat lpos[] = {0.0, 4.0, 0.0};
static GLfloat lpos2[] = {1.0, 0.0, 0.0};
static GLfloat lpos3[] = {1.0, 0.0, 0.0};

static GLfloat light_two[] = {0.5,    7.5, 3.0, 1.0};
static GLfloat light_three[]={-3.5, 1.5,    2.0, 1.0};

/* position of viewer */
static GLdouble viewer[] = {2.0, 10.0, 10.0}; 

/* vectors for translucent properties */
static GLfloat red_transparent[] = {1.0, 0.0, 0.0, 0.5};
static GLfloat yellow_transparent[] = {1.0, 1.0, 0.0, 0.7};
//====================================================================
//Class thing allows for creation of different shaped, but allows all to be drawn
//  using the same methods. Allows for easier manipulation and creation of objects later.
class thing{
public:
    int columns;
	int rows;
    int row_index;
	int col_index;
	vek pos;
	float xAngle;
	float yAngle;
    float zAngle;
	bool x_axis, y_axis, z_axis;
	plane obj[60][60];
	void init();
	void smooth_thing();
    void draw_smooth(plane, bool);
	void draw_thing();
    void half_ring(float,float , float , float , float , bool);
    void ring(float,float , float , float , float , bool );
	void rod(float, float);
	void rocket(bool);
	void dome();
    void half_rod(float, float, bool);
    void piston(float, float);
	void rect(float, float, float);
	bool is_rect;
	void move(float, float, float);
	void rot(float, bool, bool, bool);
	bool is_rod;
	bool is_half_rod;
	bool is_piston;
	bool is_rocket;
	int ring_parts;
    GLfloat color[4];
	void setColor(GLfloat *);
};

void thing::init()
{
 pos.x = 0.0;
 pos.y = 0.0;
 pos.z = 0.0;
 xAngle = 0.0;
 yAngle = 0.0;
 zAngle = 0.0;
 x_axis = false;
 y_axis = false;
 z_axis = false;
 color[0] = red[0];
 color[1] = red[1];
 color[2] = red[2];
 color[3] = red[3];
 columns = 0;
 rows = 0;
 row_index = 0;
 col_index = 0;
 is_rod = false;
 is_half_rod = false;
 is_rocket = false;
 ring_parts = 30;
}

void thing::smooth_thing()
{
 //if (smoothNormals)
 {
	//smooth vertically
 if (!is_half_rod && !is_rod)
 for (int i = 0; i < columns; i ++)
 {
 for (int j = 0; j < rows -1; j ++)
   {
    obj[i][j].aNorm = obj[i+1][j].dNorm;
    obj[i][j].bNorm = obj[i+1][j].cNorm;
   }
 }


  if (is_rod && !is_half_rod)
  {
   for (int k = 0; k < rows; k++)
   for (int l = 0; l < columns; l ++)
   { 
   	if (l == columns - 1)
	{
	 obj[k][l].bNorm = obj[k][0].aNorm;
     obj[k][l].cNorm = obj[k][0].dNorm;
	}
	else
	{
	 obj[k][l].bNorm = obj[k][l+1].aNorm;
     obj[k][l].cNorm = obj[k][l+1].dNorm;
	}
   }
  }
  
 if (is_rocket)
  {
   for (int k = 0; k < rows; k++)
   for (int l = 0; l < columns; l ++)
   { 
   	if (l == columns - 1)
	{
	 obj[k][l].bNorm = obj[k][0].aNorm;
     obj[k][l].cNorm = obj[k][0].dNorm;
	}
	else
	{
	 obj[k][l].bNorm = obj[k][l+1].aNorm;
     obj[k][l].cNorm = obj[k][l+1].dNorm;
	}
   }
  }
  if (is_half_rod)
  {
   for (int o = 0; o <rows; o++)
   	  for (int p = 0; p < ((ring_parts/2) - 1)  ; p++)
   {
    
	obj[o][p].bNorm = obj[o][p + 1].aNorm;
    obj[o][p].cNorm = obj[o][p + 1].dNorm;
   }
  }
 }
}


//***************************************************
void thing::draw_smooth(plane p, bool face)
{
  if (smoothNormals)
  {  
	if (!face)
	{
	glBegin(GL_POLYGON);
        glNormal3f(p.aNorm.x, p.aNorm.y, p.aNorm.z);
	  glVertex3f(p.a.x, p.a.y, p.a.z);
	    glNormal3f(p.bNorm.x, p.bNorm.y, p.bNorm.z);
	  glVertex3f(p.b.x, p.b.y, p.b.z);
        glNormal3f(p.cNorm.x, p.cNorm.y, p.cNorm.z);
	  glVertex3f(p.c.x, p.c.y, p.c.z);
       glNormal3f(p.dNorm.x, p.dNorm.y, p.dNorm.z);
	  glVertex3f(p.d.x, p.d.y, p.d.z);
    glEnd();
    }
	else
	{
    glBegin(GL_POLYGON);
          glNormal3f(p.aNorm.x, p.aNorm.y, p.aNorm.z);
	  glVertex3f(p.a.x, p.a.y, p.a.z);
	   glNormal3f(p.bNorm.x, p.bNorm.y, p.bNorm.z);
	  glVertex3f(p.b.x, p.b.y, p.b.z);
        glNormal3f(p.cNorm.x, p.cNorm.y, p.cNorm.z);
	  glVertex3f(p.c.x, p.c.y, p.c.z);
       glNormal3f(p.dNorm.x, p.dNorm.y, p.dNorm.z);
	  glVertex3f(p.d.x, p.d.y, p.d.z);
    glEnd();
    }
  }
  else 
  { 
   if (!face)
	{
	glBegin(GL_POLYGON);
        glNormal3f(p.normal.x, p.normal.y, p.normal.z);
	  glVertex3f(p.a.x, p.a.y, p.a.z);
	    
	  glVertex3f(p.b.x, p.b.y, p.b.z);
        
	  glVertex3f(p.c.x, p.c.y, p.c.z);
       
	  glVertex3f(p.d.x, p.d.y, p.d.z);
    glEnd();
    }
	else
	{
    glBegin(GL_POLYGON);
          glNormal3f(p.normal.x, p.normal.y, p.normal.z);
	  glVertex3f(p.a.x, p.a.y, p.a.z);
	   
	  glVertex3f(p.b.x, p.b.y, p.b.z);
       
	  glVertex3f(p.c.x, p.c.y, p.c.z);
       
	  glVertex3f(p.d.x, p.d.y, p.d.z);
    glEnd();
    }
  }
}

void thing::draw_thing()
{
 glPushMatrix();
 if (x_axis) glRotatef(xAngle, 1.0, 0.0, 0.0);
 if (y_axis) glRotatef(yAngle, 0.0, 1.0, 0.0);
 if (z_axis) glRotatef(zAngle, 0.0, 0.0, 1.0);
  
 glPushMatrix();
 glTranslatef(pos.x, pos.y, pos.z);
 
 glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, color);
 if (!is_rect)
 {
 for (int i = 0; i < rows; i ++)
 { 
	 for (int j = 0; j < columns; j ++)
	  {
		if (i > rows - 10 && is_rocket)
             glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, red);
       draw_smooth(obj[i][j], true);
	  }
 }
 }
 else
 { /////////////////////
  for (int i = 0; i < 6; i ++)
  {
    
   glNormal3f(-obj[0][i].normal.x, -obj[0][i].normal.y, -obj[0][i].normal.z);
   glBegin(GL_POLYGON);
      glVertex3f(obj[0][i].b.x, obj[0][i].b.y, obj[0][i].b.z);
      glVertex3f(obj[0][i].a.x, obj[0][i].a.y, obj[0][i].a.z);
      glVertex3f(obj[0][i].d.x, obj[0][i].d.y, obj[0][i].d.z);
   glEnd();

   glBegin(GL_POLYGON);
    glVertex3f(obj[0][i].b.x, obj[0][i].b.y, obj[0][i].b.z);
    glVertex3f(obj[0][i].d.x, obj[0][i].d.y, obj[0][i].d.z);
    glVertex3f(obj[0][i].c.x, obj[0][i].c.y, obj[0][i].c.z);
   glEnd();
  }
 }
 glPopMatrix();
 glPopMatrix();
}

void thing::ring(float bottom_radius,float top_radius, float width, float origin, float partitions, bool inside)
{ 
   GLfloat angle1;
   GLfloat angle2;
   GLfloat segment = 360 / (GLfloat) partitions;
   vek a;
   vek b;
   vek c;
   vek d;
   plane p;
   for (int i = 0; i<partitions; i++)
   {
	angle1 = ((segment * i) / 180) * PI;
	angle2 = ((segment * (i+1)) /180) * PI;
		
	if (!inside)
	{
		//Inside
       a.x = top_radius * cos(angle1); a.y = origin + width; a.z = top_radius * sin(angle1);
	   b.x =top_radius * cos(angle2); b.y = origin + width; b.z = top_radius * sin(angle2);
	   c.x =bottom_radius * cos(angle2); c.y = origin; c.z =  bottom_radius * sin(angle2);
       d.x =bottom_radius * cos(angle1); d.y = origin; d.z = bottom_radius * sin(angle1);
	   
	}
	if (inside)
	{
       //OUTSIDE
	   a.x = top_radius * cos(angle1); a.y = origin + width; a.z = top_radius * sin(angle1);
	   b.x =top_radius * cos(angle2); b.y = origin + width; b.z = top_radius * sin(angle2);
	   c.x =bottom_radius * cos(angle2); c.y = origin; c.z =  bottom_radius * sin(angle2);
       d.x =bottom_radius * cos(angle1); d.y = origin; d.z = bottom_radius * sin(angle1);
	   
	}
	   p.a = a;
	p.b = b;
	p.c = c;
	p.d = d;
    p.makeNorm();
    obj[row_index][col_index] = p;
	col_index++;
	columns++;
	if (col_index >= partitions) 
	{
     col_index = 0;
	 row_index++;
	 rows++;
	}
   }
}

void thing::half_ring(float bottom_radius,float top_radius, float width, float origin, float partitions, bool inside)
{ 
   GLfloat angle1;
   GLfloat angle2;
   GLfloat segment = 360 / (GLfloat) partitions;
   vek a;
   vek b;
   vek c;
   vek d;
   plane p;
   for (int i = 0; i<(partitions/2); i++)
   { 
	angle1 = ((segment * i) / 180) * PI;
	angle2 = ((segment * (i+1)) /180) * PI;
	if (!inside)
	{
  	   //Outside
     a.x = top_radius * cos(angle1);   a.y = origin + width; a.z = top_radius * sin(angle1);
     b.x =top_radius * cos(angle2);    b.y = origin + width; b.z = top_radius * sin(angle2);
     c.x =bottom_radius * cos(angle2); c.y = origin;         c.z = bottom_radius * sin(angle2);
     d.x =bottom_radius * cos(angle1); d.y = origin;         d.z = bottom_radius * sin(angle1);
	 p.a = a;
	 p.b = b;
	 p.c = c;
	 p.d = d;
	}
	if (inside)
	{
       //Inside
	 a.x = top_radius * cos(angle1);   a.y = origin + width; a.z = top_radius * sin(angle1);
	 b.x =top_radius * cos(angle2);    b.y = origin + width; b.z = top_radius * sin(angle2);
	 c.x =bottom_radius * cos(angle2); c.y = origin;         c.z = bottom_radius * sin(angle2);
     d.x =bottom_radius * cos(angle1); d.y = origin;         d.z = bottom_radius * sin(angle1);
	 p.a = b;
	 p.b = a;
	 p.c = d;
	 p.d = c;
	}

    p.makeNorm();
    obj[row_index][col_index] = p;
	col_index++;
	columns++;
	if (col_index >= partitions) 
	{
     col_index = 0;
	 row_index++;
	 rows++;
	}
   }
	
   
}
float absolute(float f)
{
 if (f < 0.0) f = f * -1.0;
 return f;
}

void thing::rod (float length, float radius)
{
 ring(0.001, radius,  0.0,    0.0,    ring_parts, false);
 ring(radius, radius, length, 0.0,    ring_parts, false);
 ring(radius, 0.001, 0.0,    length, ring_parts, false);
 
 rows = 3;
 columns = ring_parts; 
 is_rod = true;
}

void thing::rocket(bool tip)
{
 float angle1, angle2;
 int x = 30;
 float w = 0.025;
	 
 float scaleBy = 0.50;
 
 float width = 0.25;
 float ink = 0.0;
 float rad = 0.01;
 float start = 0.25;
 
 float end = 0.73;
 int middle = 0;
 float nose = 20.0;
 for (float j = start; j <end; j = j + w)
 {

   angle1 = ((GLfloat)((j) * 180)/180) * (2 * PI);
   angle2 = ((GLfloat)(((j+w)) * 180)/180) * (2 * PI);
   
   if (j > ((start + end)/2.0) && middle < 5)
   {
    
    middle ++;
    angle1 = ((GLfloat)((j) * 180)/180) * (2 * PI);
    if (!tip && j < nose)
	   ring((absolute(cos(angle1)) + rad) * scaleBy , (absolute(cos(angle1)) + rad) * scaleBy , width, ink * width , ring_parts, false); 
    
	ink = ink + 1.0;
    j = j - w;
   }
   else
   {
   if (!tip && j < nose)
   ring((absolute(cos(angle1)) + rad) * scaleBy , (absolute(cos(angle2)) + rad) * scaleBy , width, ink * width , ring_parts, false); 
   if (tip && j > nose)
       ring((absolute(cos(angle1)) + rad) * scaleBy , (absolute(cos(angle1)) + rad) * scaleBy , width, ink * width , ring_parts, false);
   ink = ink + 1.0;
   }
 }
 is_rocket = true;
 rows = x;
 columns = ring_parts;
}

void thing::dome()
{
float angle1, angle2;
 int x = 30;
 float w = 0.025;
 float scaleBy = 0.40;
 float width = 0.1;
 float ink = 0.0;
 float rad = 0.01;
 float start = 0.25;
 float end = 0.73;
 int middle = 0;
 float nose = 20.0;
 for (float j = start; j <end; j = j + w)
 {
   angle1 = ((GLfloat)((j) * 180)/180) * (2 * PI);
   angle2 = ((GLfloat)(((j+w)) * 180)/180) * (2 * PI);
   ring((absolute(cos(angle1)) + rad) * scaleBy , (absolute(cos(angle2)) + rad) * scaleBy , width, ink * width , ring_parts, false); 
   ink = ink + 1.0;
  }
 is_rocket = true;
 rows = x;
 columns = ring_parts;
}
void thing::half_rod (float length, float radius, bool open)
{
  half_ring(0.001, radius,  0.0,    0.0,    ring_parts, false);
  
  half_ring(radius, 0.001, 0.0,    length, ring_parts, false);
  half_ring(radius, radius, length, 0.0,    ring_parts, false);
  rows = 3;
  if (open)
  {
  plane p;
  vek temp;
  temp.x = radius; 
  temp.y = length;
  temp.z = 0.0;
  p.b = temp;
  temp.x = -radius; 
  temp.y = length;
  temp.z = 0.0;
  p.a = temp;
  temp.x = -radius; 
  temp.y = 0.0;
  temp.z = 0.0;
  p.d = temp;
  temp.x = radius; 
  temp.y = 0.0;
  temp.z = 0.0;
  p.c = temp;
  p.makeNorm();
  rows = 4;
  obj[row_index][col_index] = p;
  row_index++;
  }
  columns = ring_parts;  
  is_half_rod = true;
}


void thing::piston (float length, float radius)
{
 float inkr = radius/12;
 ring(radius,  radius,                   length, 0.0,               ring_parts,   false);
 ring(radius , radius - (2 * inkr),        2 * inkr,    length,    ring_parts, false);
 rows = 2;
 columns = ring_parts; 
 is_rod = true;
}

void thing::rect(float w, float h, float l)
{
 is_rect = true;
 plane p;
 vek temp;
 columns = 6;
 rows = 1;
 //---------------------------------------
 temp.x = 0.0; temp.y = h; temp.z = l;
 p.a = temp;
 temp.x = w;   temp.y = h; temp.z = l;
 p.b = temp;
 temp.x = w; temp.y = 0.0; temp.z = l;
 p.c = temp;
 temp.x = 0.0;   temp.y = 0.0; temp.z = l;
 p.d = temp;
 p.makeNorm();
 obj[row_index][col_index] = p;
 col_index ++;
 //------------------------------------------
 p.a = obj[row_index][0].b;
 p.d = obj[row_index][0].c;
 temp.x = w; temp.y = h; temp.z = 0.0;
 p.b = temp;
 temp.x = w; temp.y = 0.0; temp.z = 0.0;
 p.c = temp;
 p.makeNorm();
 obj[row_index][col_index] = p;
 col_index++;
 //------------------------------------------
 p.a = obj[row_index][col_index -1].b;
 p.d = obj[row_index][col_index -1].c;
 temp.x = 0.0; temp.y = h; temp.z = 0.0;
 p.b = temp;
 temp.x = 0.0; temp.y = 0.0; temp.z = 0.0;
 p.c = temp;
 p.makeNorm();
 obj[row_index][col_index] = p;
 col_index++;
 //-------------------------------------------
 p.a = obj[row_index][2].b;
 p.b = obj[row_index][0].a;
 p.c = obj[row_index][0].d;
 p.d = obj[row_index][2].c;
 
 p.makeNorm();
 obj[row_index][col_index] = p;
 col_index++;
 //------------------------------------------
 p.a = obj[row_index][2].b;
 p.b = obj[row_index][2].a;
 p.c = obj[row_index][0].b;
 p.d = obj[row_index][0].a;
 p.makeNorm();
 obj[row_index][col_index] = p;
 col_index++;
 //---------------------------------------
 p.a = obj[row_index][2].d;
 p.b = obj[row_index][2].c;
 p.c = obj[row_index][0].d;
 p.d = obj[row_index][0].c;
 p.makeNorm();
 obj[row_index][col_index] = p;
 col_index++;
}

void thing::move(float x, float y, float z)
{
 pos.x = x;
 pos.y = y;
 pos.z = z;
}

void thing::rot(float ang, bool x, bool y, bool z)
{
 if (x) 
 { 
	  xAngle = ang;
 x_axis = x;
 }
 if (y) 
 {
	 yAngle = ang;
 y_axis = y;
 }
 if (z)
 {
    zAngle = ang;
	 z_axis = z;
 }

}
void thing::setColor(GLfloat * c)
{
 color[0] = c[0];
 color[1] = c[1];
 color[2] = c[2];
 color[3] = c[3];
}

//======================================================================
//Allows to bind together instances of class "Thing" for easier manipulation
class movingPart {
public:
	thing * parts;
	vek pos;
   int partSize;
   ~movingPart();
   void setPartSize(int);
   void drawAll();
   void move(float, float, float);
};

movingPart::~movingPart()
{
 delete [] parts;
}

void movingPart::setPartSize(int size)
{
  parts = new thing[size];
  partSize = size;
}

void movingPart::drawAll()
{
 for (int i = 0; i < partSize; i ++)
 {
    glPushMatrix();
	 glTranslatef(pos.x, pos.y, pos.z);
	 parts[i].draw_thing();
    glPopMatrix();
 }
}
 void movingPart::move(float x, float y, float z)
 {
  pos.x = x;
  pos.y = y;
  pos.z = z;
 }

//************FUNCTION NORM**************************
//Given 3 points, Function returns a unit normal vector
float *  norm(float * result, float x1,float y1, float z1, float x2, float y2, float z2,
			   float x3, float y3, float z3)
{
 float a[3];
 float b[3];
 a[0] = x1 - x2;
 a[1] = y1 - y2;
 a[2] = z1 - z2;
 b[0] = x1 - x3;
 b[1] = y1 - y3;
 b[2] = z1 - z3;
 result[0] = (a[1] * b[2]) - (a[2]* b[1]);
 result[1] = (a[2] * b[0]) - (a[0] * b[2]);
 result[2] = (a[0] * b[1]) - (a[1] * b[0]);
 float magn = sqrt((result[0] * result[0]) + (result[1] * result[1]) + (result[2]*result[2]));
 result[0] = (result[0] / magn);
 result[1] = (result[1] / magn);
 result[2] = (result[2] / magn);
 return result;
}

//******************FUNCTION MAKENORM***********************
//Produces normal vectors for plane class
void plane::makeNorm()
{
float temp[3];
norm(temp, a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z);\
normal.x = temp[0];
normal.y = temp[1];
normal.z = temp[2];
aNorm = normal;
bNorm = normal;
cNorm = normal;
dNorm = normal;
}


//***************FUNCTION NORMALIZE************************
vek normalize(vek a)
{
 float magn = sqrt((a.x * a.x) + (a.y * a.y) + (a.z * a.z));
 a.x = a.x / magn;
 a.y = a.y / magn;
 a.z = a.z / magn;
 return a;
}

//************FUNCTION WRITEMESSAGE*****************
void writemessage()
{
   printf("\n\
   program3.cpp by Joe Baldwin\n\
   Extra: All curved surfaces have blended normals\n\
   Extra: blended normals can be toggled on/off with right mouse click\n\
   Extra: Ride is raised and lowered with 3 Pistons \n\
    uses double buffering for smooth animation\n\
   Left mouse click ---------- Start Rocket Ride\n\
   Middle Mouse click -------- Stop Rocket Ride\n\
   Right Mouse click --------- Extra: Toggle normal blending for each face\n\
   a, A, b, B, c, C ---------- change light source position\n\
   x, X, y, Y, z, Z ---------- change viewer position\n\
   1, 2, 3, 4, 5, 6 ---------- change to preset viewer positions\n\
   ESC ----------------------- exit\n\
   \n");
}

//***********FUNCTION RESHAPE***********************
void reshape(int w, int h)
{
   glViewport(0, 0, (GLsizei) w, (GLsizei) h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluPerspective(45.0, (GLfloat) w / (GLfloat) h, 1.0, 30.0);
   glMatrixMode(GL_MODELVIEW);
}


float pAngle;
float rAngle;
float armAngle;
movingPart Joint;
movingPart Arm;
movingPart Rocket;
movingPart Rocket2;
movingPart Steps1;
movingPart Steps2;
movingPart SpinLight;
thing bottom;

thing pist1;
thing pist2;
thing pist3;

thing joint_right;
thing joint_right_top;
thing joint_bottom;
thing joint_left;
thing joint_left_top;
thing pole;
thing clamp;
thing clamp2;

thing axis;
thing axis_y;
thing rockt;
//thing rockt_tip;
thing fin;
thing fin2;
thing dome;
thing lightHalf1;
thing lightHalf2;


thing step1;
thing step2;
thing step3;

thing ropePole;
thing ropePoleTop;
thing rope1;
thing rope2;
thing rope3;
thing rope4;
thing rope5;
thing rope6;

thing block1;
thing block2;
thing block3;
thing block4;
thing block5;
thing block6;

movingPart Block;
movingPart Rope;

void warnLights(void)
{
 lightAngle = lightAngle + 5.0;
 if (lightAngle > 359.0) lightAngle = 0.0;
 glutPostRedisplay();
}

void initParts()
{
   joint_bottom.init();
   joint_bottom.rect(0.6, 0.1, 0.5);
   joint_bottom.setColor(green);
   

   joint_right.init();
   joint_right.rect(0.1, 0.5, 0.5);
   joint_right.setColor(green);
   joint_right.move(0.5, 0.1, 0.0);

   joint_right_top.init();
   joint_right_top.half_rod(0.1, 0.25, false);
   joint_right_top.smooth_thing();
   joint_right_top.setColor(green);
   joint_right_top.rot(270.0, true, false, false);
   joint_right_top.rot(90.0, false, false, true);
   joint_right_top.move(-0.25, -0.6, 0.6);

   joint_left.init();
   joint_left.rect(0.1, 0.5, 0.5);
   joint_left.setColor(green);
   joint_left.move(0.0, 0.1, 0.0);
   
   joint_left_top.init();
   joint_left_top.half_rod(0.1, 0.25, false);
   joint_left_top.smooth_thing();
   joint_left_top.setColor(green);
   joint_left_top.rot(270.0, true, false, false);
   joint_left_top.rot(90.0, false, false, true);
   joint_left_top.move(-0.25, -0.1, 0.60);

    
   Joint.setPartSize(5);
   Joint.parts[0] = joint_bottom;
   Joint.parts[1] = joint_right;
   Joint.parts[2] = joint_left;
   Joint.parts[3] = joint_right_top;
   Joint.parts[4] = joint_left_top;

   Joint.move(-0.3, 0.0, -0.25);
   bottom.init();
   bottom.rect(20.0, 0.25, 20.0);
   bottom.setColor(cyan);
   bottom.move(-10.0, -2.0, -10.0);
   
   pole.init();
   pole.rod(9.0, 0.20);
   pole.smooth_thing();
   pole.setColor(blue);
   pole.rot(90, true, false, false);

   clamp.init();
   clamp.rod(0.5, 0.65);
   clamp.smooth_thing();
   clamp.setColor(blue);
   clamp.rot(90.0, false, false, true);
   clamp.move(0.0, -0.25, 9.5);
   
   
   clamp2.init();
   clamp2.rod(0.5, 0.65);
   clamp2.smooth_thing();
   clamp2.setColor(blue);
   clamp2.rot(90.0, false, false, true);
   clamp2.move(0.0, -0.25, -0.5);
   
   Arm.setPartSize(3);
   Arm.parts[0] = pole;
   Arm.parts[1] = clamp;
   Arm.parts[2] = clamp2;
   Arm.move(0.0, -0.2, -4.5);
   
   axis.init();
   axis.rect(0.1, 5.0, 0.1);
   axis.move(-0.05, 0.0, -0.05);
   axis.setColor(yellow);

   axis_y.init();
   axis_y.rect(5.0, 0.1, 0.1);
   axis_y.move(-2.5, 0.05, -0.05);
   axis_y.setColor(yellow);
   float rad = 0.25;
   pist1.init();
   pist1.piston(1.0, rad);
   pist1.smooth_thing();
   pist1.setColor(green);

   pist2.init();
   pist2.piston(1.0, (rad - (rad/6)));
   pist2.smooth_thing();
   pist2.setColor(green);

   pist3.init();
   pist3.rod(1.0, (rad - (2 * (rad/6))));
   pist3.smooth_thing();
   pist3.setColor(green);

   rockt.init();
   rockt.rocket(false);
   rockt.smooth_thing();
   rockt.setColor(gray);

   fin.init();
   fin.half_rod(0.10, 1.0, true);
   fin.smooth_thing();
   fin.rot(-90.0, true, false, false);
   fin.rot(90.0, false, false, true);
   fin.move(0.0, -0.05, 0.0);
   
   fin.setColor(red);

   fin2.init();
   fin2.half_rod(0.10, 1.0, true);
   fin2.smooth_thing();
   fin2.rot(-90.0, true, false, false);
   fin2.move(0.0, -0.05, 0.0);
   
   fin2.setColor(red);

   dome.init();
   dome.dome();
   dome.move(-0.5, 2.0, 0.0);
   dome.smooth_thing();
   dome.setColor(blue);

   Rocket.setPartSize(4);
   Rocket.parts[0] = rockt;
   Rocket.parts[1] = fin;
   Rocket.parts[2] = fin2;
   Rocket.parts[3] = dome;

   Rocket.move(0.0, -0.47, 0.0);


   Rocket2.setPartSize(4);
   Rocket2.parts[0] = rockt;
   Rocket2.parts[1] = fin;
   Rocket2.parts[2] = fin2;
   Rocket2.parts[3] = dome;

   Rocket2.move(0.0, -0.47, 0.0);

   step1.init();
   step1.rect(1.0, 0.25, 1.0);
   step1.setColor(magenta);
   step2.init();
   step2.rect(1.0, 0.25, 0.75);
   step2.move(0.0, 0.25, 0.0);
   step2.setColor(magenta);
   step3.init();
   step3.rect(1.0, 0.25, 0.5);
   step3.move(0.0, 0.5, 0.0);
   step3.setColor(magenta);

   Steps1.setPartSize(3);
   Steps1.parts[0] = step1;
   Steps1.parts[1] = step2;
   Steps1.parts[2] = step3;

   lightHalf1.init();
   lightHalf1.half_rod(0.5, 0.2, false);
   lightHalf1.setColor(lightColor);
   lightHalf1.smooth_thing();


   lightHalf2.init();
   lightHalf2.half_rod(0.5, 0.2, false);
   lightHalf2.setColor(gray);
   lightHalf2.smooth_thing();
   lightHalf2.rot(180.0, false, true, false); 
   
   
   SpinLight.setPartSize(2);
   SpinLight.parts[0] = lightHalf1;
   SpinLight.parts[1] = lightHalf2;

   ropePole.init();
   ropePole.rect(0.25, 3.0, 0.25);
   ropePole.setColor(gray);

   ropePoleTop.init();
   ropePoleTop.rod(2.25, 0.2);
   ropePoleTop.setColor(yellow);
   ropePoleTop.move(0.1, 3.0, 0.15);
   
   float raz = 0.4;
  
   
   rope2.init();
   rope2.rect(5.5, 0.1, 0.1);
   rope2.setColor(gray);
   rope2.move(0.0, 0.66 + raz, 0.0);
   

   rope3.init();
   rope3.rect(5.5, 0.1, 0.1);
   rope3.setColor(gray);
   rope3.move(0.0, 1.32 + raz, 0.0);
   
   rope4.init();
   rope4.rect(5.5, 0.1, 0.1);
   rope4.setColor(gray);
   rope4.move(0.0, 1.98 + raz, 0.0);
   
   Rope.setPartSize(4);
   Rope.parts[0] = ropePole;
   
   Rope.parts[1] = rope2;
   Rope.parts[2] = rope3;
   Rope.parts[3] = rope4;

   block1.init();
   block1.rect(2.0, 0.5, 2.0);
   block1.setColor(red);

   block2.init();
   block2.rect(2.0, 0.45, 0.05);
   block2.setColor(white);
   block2.move(0.0,0.0, 2.0);

   block3.init();
   block3.rect(2.0, 0.45, 0.05);
   block3.setColor(white);
   block3.move(0.0,0.0, -0.05);

   block4.init();
   block4.rect(0.05, 0.45, 2.1);
   block4.setColor(white);
   block4.move(2.0, 0.0, -0.05);

   block5.init();
   block5.rect(0.05, 0.45, 2.1);
   block5.setColor(white);
   block5.move(-0.05, 0.0, -0.05);


   Block.setPartSize(5);
   Block.parts[0] = block1;
   Block.parts[1] = block2;
   Block.parts[2] = block3;
   Block.parts[3] = block4;
   Block.parts[4] = block5;
 }



//***************FUNCTION INIT*******************************
void init(void) 
{
   writemessage(); 
   //glClearColor(1.0, 1.0, 1.0, 1.0);
   glClearColor(0.0, 0.0, 0.0, 0.0);
   glShadeModel(GL_SMOOTH);
   pAngle = 0.0;
   rAngle = 90.0;
   rAngle2 = 270.0;
   increment = 0.1;
   //glEnable(GL_BLEND);
   //glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   //glEnable(GL_POLYGON_SMOOTH);
   
   glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
   
      /* initially GL_FILL mode, later GL_LINE to show wireframe */
   glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
      /* enable two-sided lighting to properly show interior of cube */
   glEnable(GL_DEPTH_TEST);
   glEnable(GL_LIGHTING);
   
   GLfloat light_ambient[] = { 1.0, 1.0, 1.0, 1.0 };  //was x x x 1.0
   GLfloat light_diffuse[] = { 1.0, 1.0, 1.0, 1.0 };
   GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };
   GLfloat light1_direction[] = {0.0, -1.0, 0.0};
  
   GLfloat cut = 1.0;
   GLfloat expo = 20.0;
  
   glLightfv(GL_LIGHT0, GL_DIFFUSE, white);
   //glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
   glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 0.025);
   glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 0.025);
   glLightf(GL_LIGHT0, GL_QUADRATIC_ATTENUATION, 0.025);
   
   glLightfv(GL_LIGHT1, GL_DIFFUSE, lightColor);
   glLightfv(GL_LIGHT1, GL_SPECULAR, light_specular);
   glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, 0.05);
   glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.05);
   glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, 0.05);
   //glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, light1_direction);
   //glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 22.5);
   //glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 20.0);

 glLightfv(GL_LIGHT2, GL_DIFFUSE, lightColor);
   glLightfv(GL_LIGHT2, GL_SPECULAR, light_specular);
   glLightf(GL_LIGHT2, GL_CONSTANT_ATTENUATION, 0.05);
   glLightf(GL_LIGHT2, GL_LINEAR_ATTENUATION, 0.05);
   glLightf(GL_LIGHT2, GL_QUADRATIC_ATTENUATION, 0.05);

   
   glEnable(GL_LIGHT1);
   glEnable(GL_LIGHT2);
   //glEnable(GL_LIGHT0);
   
   theFloor = glGenLists(1);
   glNewList(theFloor, GL_COMPILE);
      int color = 0;
   glNormal3f(0.0, 1.0, 0.0);
   glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, white);
   for (int k = 0;  k< 45 ; k++)
   {
    for (int j = 0; j <45; j++)
	{
	 if (color % 2 == 0)	
     glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, white);
     if (color % 2 ==1)		
     glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, black);
     glBegin(GL_POLYGON);
	  glVertex3f(-5.0 + k , 0.0,-5.0 + j );
      glVertex3f( -5.0 + k , 0.0,-4.0 + j );
	  glVertex3f( -4.0 + k , 0.0, -4.0 + j );
	 glEnd();
	 
	 glBegin(GL_POLYGON);
	  glVertex3f(-4.0 + k , 0.0, -5.0 + j );
      glVertex3f(-5.0 + k , 0.0,-5.0 + j );
      glVertex3f( -4.0 + k , 0.0, -4.0 + j );
	 glEnd();
     color ++;
	}
   }


   glEndList();
   
   
   initParts();
   
   theFence = glGenLists(1);
   glNewList(theFence, GL_COMPILE);
   float ropeAngle = 0.0; 
 float realRopeAngle = 0.0;
 glPushMatrix();
 
 glTranslatef(0.0, -4.0, 0.0);
 for (int z = 0;  z< 12; z ++)
 {
  realRopeAngle = (realRopeAngle/360.00) * 2 * PI;
 glPushMatrix(); 
   
   
   glRotatef(ropeAngle, 0.0, 1.0, 0.0);
   //glRotatef(90, 0.0, 1.0, 0.0);
   glTranslatef( cos(realRopeAngle) * 10.0, 0.0 ,sin(realRopeAngle) * 10.0);
   glRotatef(105.0, 0.0, 1.0, 0.0);
   Rope.drawAll();
   
 glPopMatrix();
 //ropeAngle = ropeAngle + (360/12);
 ropeAngle = ropeAngle + (360/12);
 }
 glPopMatrix();
   glEndList();
   
   
   glutIdleFunc(warnLights);
   
}
bool up = true;
bool down = false;
float base = 0.0;

float piston_two = 0.0;
float piston_three = 0.0;






//**************************************
 void lower(void)
 {
  lightAngle = lightAngle + 5.0;
  if (lightAngle > 359.0) lightAngle = 0.0;
  
  if (increment > 1.0)
  {
  time = time + 1;
  if (time == 20) time = 0;
  if (time % 10 == 0)
  {
     if (increment > 0.5 ) increment = increment - 0.5;
     //cout<<"In Lower"<<endl;
  }
	 pAngle = pAngle + increment;
     if (pAngle >= 359.0) pAngle = 0.0;
   rAngle = rAngle + increment;
     if (rAngle >= 359.0) rAngle = 0.0;
   rAngle2 = rAngle2 + increment;
     if (rAngle2 >= 359.0) rAngle2 = 0.0;
   base = base + increment;
   if (base >=360) base = 0.0;
   armAngle = sin((base/360) * 2 * PI) * 30;
  }
  if (increment <= 1.0)
   { /////////////////////////////
   
   
	if ((pAngle < 1.5) || (pAngle> 178.5 && pAngle < 181.5))
		pAngleDone = true;
	else
   	if (!pAngleDone)
	{
 
      pAngle = pAngle + increment;
      if (pAngle >= 359.0) pAngle = 0.0;
	 }
  
   if ((armAngle < 1.0) || (armAngle > 179.0 && armAngle < 181.0))
	//if ((armAngle > 89.0 && armAngle < 91.0))
   	   armAngleDone = true;
   else   
    if (!armAngleDone)
	{
     base = base + increment;
     if (base >=360) base = 0.0;
     armAngle = sin((base/360) * 2 * PI) * 30;
	}

   //--------------------------
  
   if (rAngle > 89.0 && rAngle < 91.0)
	   rAngleDone = true;
   else
    if (!rAngleDone)
   {
    rAngle = rAngle + increment;
    if (rAngle >= 359.0) rAngle = 0.0;
   }
   if (rAngle2 > (271.0) ||  rAngle2 < (269.0)  )
   {
    rAngle2 = rAngle2 + increment;
    if (rAngle2 >= 359.0) rAngle2 = 0.0;
   }
   
   //---------------------------
 if (armAngleDone && pAngleDone && rAngleDone)
 {	 
  if (piston_three > 0.0)
  {
   piston_three = piston_three - 0.05;
  }
  if (piston_three <= 0.0)
  {
    if (piston_two > 0.0)
	{

     piston_two = piston_two - 0.05;
	}
  }
 }
   if (piston_two <= 0.0)
   {
	   SpinLight.parts[0].setColor(green);
      is_raise = false;
   }
   
   
   
 }  //////////////////////////////


  glutPostRedisplay();
 }
//************************************************
 void raise(void)
 {
	 //rideLimit = 0;
	 is_raise = true;
  if(armAngleDone)
	{
     armAngleDone = false;
	 pAngleDone = false;
	 rAngleDone = false;
	 }
  SpinLight.parts[0].setColor(red);
  
  lightAngle = lightAngle + 5.0;
  if (lightAngle > 359.0) lightAngle = 0.0;
  if (piston_three < 1.0)
  {
   piston_three = piston_three + 0.05;
  }
  if (piston_three >= 1.0)
  {
   if (piston_two < 1.0)
   {
     piston_two = piston_two + 0.05;
   }
  }
  if (piston_two >= 1.0)
  {
  time = time + 1;
  if (time == 20) time = 0;
  if (time % 10 == 0)
  if (increment < 5.0)  increment = increment + 0.25;
  pAngle = pAngle + increment;
  if (pAngle >= 359.0) pAngle = 0.0;
  rAngle = rAngle + increment;
  if (rAngle >= 359.0) rAngle = 0.0;
  rAngle2 = rAngle2 + increment;
  if (rAngle2 >= 359.0) rAngle2 = 0.0;
  base = base + increment;
  if (base >=360) base = 0.0;
  armAngle = sin((base/360) * 2 * PI) * 30;
  }
  rideTimer++;
  if (rideTimer> 20)
  {
   rideTimer = 0;
   rideLimit++;
  }

  glutPostRedisplay();
 }

//******FUNCTION DISPLAY**************************
void display(void)
{
   
	if (rideLimit > 20) glutIdleFunc(lower);

	glutSetWindow(window1); 
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
     
   
   static int i;
   static double angle, Y, Z, normalY, normalZ;
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   /* initialize (modelview) matrix */
   glLoadIdentity(); 
   /*  - viewer position is set first by gluLookat
    *  - then light0 position is set and all objects are drawn
    *  - the order is important (there are exceptions, more later) */
   /* update viewer position */
   gluLookAt(viewer[0], viewer[1], viewer[2], 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
   /* update light source position */
   
   if (is_raise)
   {
      glLightfv(GL_LIGHT1, GL_DIFFUSE, red);
     glLightfv(GL_LIGHT2, GL_DIFFUSE, red);
	  }
   if (!is_raise)
   {
     glLightfv(GL_LIGHT1, GL_DIFFUSE, green);
     glLightfv(GL_LIGHT2, GL_DIFFUSE, green);
   }
     glLightfv(GL_LIGHT0, GL_POSITION, lpos);
   
    /* draw sphere to show light source */
   
     glMaterialfv(GL_FRONT, GL_EMISSION, white); 
   
   glPushMatrix();
     glTranslatef(lpos[0],lpos[1],lpos[2]);
     glutSolidSphere(0.1, 10, 8);
   glPopMatrix();
       /* remaining objects do not emit light */
   glMaterialfv(GL_FRONT, GL_EMISSION, none);
   /* note: need to set BACK material properties of the table since
    * BACK becomes visible when viewer position goes down */
   glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, white);
   glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, high);
   glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, low);
   
  /*
    Block.drawAll();
	glPushMatrix();
        glTranslatef(2.1, 0.0, 0.0);
        Block.drawAll();
	glPopMatrix();

	glPushMatrix();
        glTranslatef(0.0, 0.0, -2.1);
        Block.drawAll();
	glPopMatrix();

	glPushMatrix();
	    glTranslatef(2.1, 0.0, -2.1);
        Block.drawAll();
	glPopMatrix();
	*/
   //**************************************************

       glPushMatrix();
       glTranslatef(0.0, -3.80, 0.0);
       
       glPushMatrix();
	      glTranslatef(0.0, piston_two, 0.0);
	   
          glPushMatrix();
		    glTranslatef(0.0, piston_three, 0.0);
	
          	glPushMatrix();
                glRotatef(pAngle, 0.0, 1.0, 0.0);   //SPIN ARM
                glTranslatef(0.0, 1.8, 0.0);
				glPushMatrix();
				   glTranslatef(0.0, -0.8, 0.0);
	
			    glPopMatrix();
				glPushMatrix();
                glRotatef(armAngle, 1.0, 0.0, 0.0); //UP AND DOWN ARM
	
                glPushMatrix();
	                glRotatef(90.0 , 1.0, 0.0, 0.0); //********************
	                glRotatef(90.0, 0.0, 0.0, 1.0);
	                glTranslatef(-5.0, -1.0, 0.25); //-----------
					glPushMatrix();
	                     glRotatef(rAngle2, 0.0, 1.0, 0.0); //SPIN ROCKET
	                     //Rocket.drawAll();
                         glTranslatef(-0.4, 1.5, 0.0);
						 glRotatef(90.0, 0.0, 0.0, 1.0);
                         glRotatef(lightAngle, 0.0, 1.0, 0.0);
						 glPushMatrix();
						   //glTranslatef(0.0, 0.5, 0.0);
						   glLightfv(GL_LIGHT1, GL_POSITION, lpos2);
						   SpinLight.drawAll();
						 glPopMatrix();
					
						 glPopMatrix();
	            glPopMatrix();
	            glPushMatrix();
	                glRotatef(90.0, 1.0, 0.0, 0.0); //***********************
            	    glRotatef(90.0, 0.0, 0.0, 1.0);
		            glRotatef(180.0, 1.0, 0.0, 0.0);
		            glTranslatef(5.0, -1.0, -0.25); //-------------------
		            glPushMatrix();
	                     glPushMatrix();
					       glRotatef(rAngle, 0.0, 1.0, 0.0);  //SPIN ROCKET
	                       //Rocket2.drawAll();
                           glTranslatef(-0.4, 1.5, 0.0);
						   glRotatef(90.0, 0.0, 0.0, 1.0);
						   glRotatef(lightAngle, 0.0, 1.0, 0.0);
						   
						   glLightfv(GL_LIGHT2, GL_POSITION, lpos3);
						   SpinLight.drawAll();
						 glPopMatrix();
                    glPopMatrix();
	            glPopMatrix();
		    glPopMatrix();
	   glPopMatrix();
	//////////////////////
	  glPopMatrix();
	glPopMatrix();
   glPopMatrix();
 
   glCallList(theFence);

//*******************************************************
   glPushMatrix();
     glTranslatef(-8.0, -3.8, -8.0);
     glCallList(theFloor);
   glPopMatrix();
     
//****************************************************
   glPushMatrix();
       glTranslatef(0.0, -3.80, 0.0);
       pist1.draw_thing();
       glPushMatrix();
	      glTranslatef(0.0, piston_two, 0.0);
	      pist2.draw_thing();
          glPushMatrix();
		    glTranslatef(0.0, piston_three, 0.0);
		    pist3.draw_thing();
          	glPushMatrix();
                glRotatef(pAngle, 0.0, 1.0, 0.0);   //SPIN ARM
                glTranslatef(0.0, 1.8, 0.0);
				glPushMatrix();
				   glTranslatef(0.0, -0.8, 0.0);
		           Joint.drawAll();
			    glPopMatrix();
				glPushMatrix();
                glRotatef(armAngle, 1.0, 0.0, 0.0); //UP AND DOWN ARM
	            Arm.drawAll();
                glPushMatrix();
	                glRotatef(90.0 , 1.0, 0.0, 0.0); //********************
	                glRotatef(90.0, 0.0, 0.0, 1.0);
	                glTranslatef(-5.0, -1.0, 0.25); //-----------
					glPushMatrix();
	                     glRotatef(rAngle2, 0.0, 1.0, 0.0); //SPIN ROCKET
	                     Rocket.drawAll();
                         glTranslatef(-0.5, 1.5, 0.0);
						 glRotatef(90.0, 0.0, 0.0, 1.0);
                         glRotatef(lightAngle, 0.0, 1.0, 0.0);
						 //SpinLight.drawAll();
					glPopMatrix();
	            glPopMatrix();
	            glPushMatrix();
	                glRotatef(90.0, 1.0, 0.0, 0.0); //***********************
            	    glRotatef(90.0, 0.0, 0.0, 1.0);
		            glRotatef(180.0, 1.0, 0.0, 0.0);
		            glTranslatef(5.0, -1.0, -0.25); //-------------------
		            glPushMatrix();
	                     glPushMatrix();
					       glRotatef(rAngle, 0.0, 1.0, 0.0);  //SPIN ROCKET
	                       Rocket2.drawAll();
                           glTranslatef(-0.5, 1.5, 0.0);
						   glRotatef(90.0, 0.0, 0.0, 1.0);
						   glRotatef(lightAngle, 0.0, 1.0, 0.0);
						   //SpinLight.drawAll();
						 glPopMatrix();
                    glPopMatrix();
	            glPopMatrix();
		    glPopMatrix();
	   glPopMatrix();
	//////////////////////
	  glPopMatrix();
	glPopMatrix();
   glPopMatrix();
 
   
   glFlush();
   glutSwapBuffers();


   //**************WINDOW 2!!!!*******************************
   //********************************************************

   glutSetWindow(window2); 
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   
   
   
 
   /* initialize (modelview) matrix */
   glLoadIdentity(); 
   /*  - viewer position is set first by gluLookat
    *  - then light0 position is set and all objects are drawn
    *  - the order is important (there are exceptions, more later) */
   /* update viewer position */
   //gluLookAt(observer[0], observer[1], observer[2], 0.0, 10.0, 5.0, 0.0, 1.0, 0.0);
   gluLookAt(observer[0], observer[1], observer[2], 0.0, 1.5, 1.0, 0.0, 1.0, 0.0);
   
   
   if (is_raise)
   {
      glLightfv(GL_LIGHT1, GL_DIFFUSE, red);
     glLightfv(GL_LIGHT2, GL_DIFFUSE, red);
	  }
   if (!is_raise)
   {
     glLightfv(GL_LIGHT1, GL_DIFFUSE, green);
     glLightfv(GL_LIGHT2, GL_DIFFUSE, green);
   }
    /* draw sphere to show light source */
   if (light ==1 || light==0) 
     glMaterialfv(GL_FRONT, GL_EMISSION, white); 
   else
     glMaterialfv(GL_FRONT, GL_EMISSION, none);
   glLightfv(GL_LIGHT0, GL_POSITION, lpos);
   glPushMatrix();
     glTranslatef(lpos[0],lpos[1],lpos[2]);
     glutSolidSphere(0.1, 10, 8);
   glPopMatrix();
   
     /* remaining objects do not emit light */
   glMaterialfv(GL_FRONT, GL_EMISSION, none);
   /* note: need to set BACK material properties of the table since
    * BACK becomes visible when viewer position goes down */
   glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE, white);
   glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, medium);
   glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, high);
   
   glPushMatrix();
       glRotatef(90.0, 0.0, 0.0, 1.0);
       glRotatef(180.0, 0.0, 1.0, 0.0);
	   glRotatef(90.0, 1.0, 0.0, 0.0);
	   glPushMatrix();
	   glRotatef(90.0, 0.0, 0.0, 1.0);
	   glTranslatef(1.5, 0.35, 0.0);
	   glPushMatrix();
            glRotatef(lightAngle, 0.0, 1.0, 0.0);
			glLightfv(GL_LIGHT1, GL_POSITION, lpos2);
			SpinLight.drawAll();
	   glPopMatrix();
	   glPopMatrix();
	   Rocket.drawAll();
   glPopMatrix();	 
   
   glRotatef(rAngle2, 0.0, 0.0, 1.0); //SPIN EVERYTHING 
   glRotatef(90.0, 0.0, 0.0, 1.0);
   glPushMatrix();
      glRotatef(90.0, 0.0,1.0, 0.0);
      glTranslatef(1.0, 0.2, -5.0);
      Arm.drawAll();
   glPopMatrix();
   glPushMatrix();
	  glRotatef(90.0, 1.0, 0.0, 0.0);
	  glRotatef(180.0, 0.0, 1.0, 0.0);
	  glTranslatef(10.0, -2.0, 0.0);
	  glPushMatrix();
	     glRotatef(rAngle, 0.0, 1.0, 0.0);
	     Rocket2.drawAll();
		
	  glPopMatrix();
   glPopMatrix();
   glTranslatef(-5.0, 0.0, -2.0);
   glRotatef(-armAngle, 0.0, 0.0, 1.0); //UP AND DOWN ARM
   glTranslatef(0.0, 0.0, 1.0);
   glRotatef(90.0, 0.0, 1.0, 0.0);
   glTranslatef(0.0, -0.5, 0.0);
   Joint.drawAll();
   glRotatef(-pAngle, 0.0, 1.0, 0.0); 
   glTranslatef(0.0, -1.0, 0.0);
   pist3.draw_thing();
   glTranslatef(0.0, -piston_two, 0.0);
   pist2.draw_thing();
   glTranslatef(0.0, -piston_three, 0.0);
   pist1.draw_thing();
   glTranslatef(-10.0, 0.0, -10.0);
   glCallList(theFloor);
   glPushMatrix();
       glTranslatef(10.0, 4.0, 10.0);
       glCallList(theFence);
   glPopMatrix();
  
   
   ////////////////////
 
   glFlush();
   glutSwapBuffers();
}

//*****************FUNCTION KEYBOARD************************ 
/* exit program with "esc" key 
 * light source position controlled by "a", "A", "b", "B", "c", "C"
 * viewer position controlled by "x", "X", "y", "Y", "z", "Z"
 * preset viewer position 1, 2, 3, 4, 5, 6
 * switch between lights 1-3 --> 8,9,0
 * switch all lights on/off a/A
 * toggle transparency t
 * toggle Table T
 * start/stop swirling spheres animation M,m */
void keyboard(unsigned char key, int x, int y)
{
   static int filled=1;
   switch (key) {
      case 27:
         exit(0);
         break; 
           
		  
       /* "w" for switching between GL_FILL and GL_LINE */
         case 'w':
         if (filled) {
           filled = 0;
           glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
         }
         else {
           filled = 1;
           glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
         }; 
         glutPostRedisplay();
         break;
       /* control lpos */
      case 'a':                
         lpos[0] = lpos[0] + 0.2;
         glutPostRedisplay();
         break;
      case 'A':                 
         lpos[0] = lpos[0] - 0.2;
         glutPostRedisplay();
         break;
      case 'b':                
         lpos[1] = lpos[1] + 0.2;
         glutPostRedisplay();
         break;
      case 'B':                 
         lpos[1] = lpos[1] - 0.2;
         glutPostRedisplay();
         break;
      case 'c':                
         lpos[2] = lpos[2] + 0.2;
         glutPostRedisplay();
         break;
      case 'C':                 
         lpos[2] = lpos[2] - 0.2;
         glutPostRedisplay();
         break;
    /* control viewer position */
      case 'l':                
         observer[0] = observer[0] + 0.4;
         glutPostRedisplay();
         break;
      case 'L':                 
         observer[0] = observer[0] - 0.4;
         glutPostRedisplay();
         break;
      case 'o':                
         observer[1] = observer[1] + 0.4;
         glutPostRedisplay();
         break;
      case 'O':                 
         observer[1] = observer[1] - 0.4;
         glutPostRedisplay();
         break;
      case 'p':                
         observer[2] = observer[2] + 0.4;
         glutPostRedisplay();
         break;
      case 'P':                 
         observer[2] = observer[2] - 0.4;
         glutPostRedisplay();
         break;


 	  // Preset Camera Positions 1-6
	  //***********************************************
	  case '1':                
         viewer[0] = 0.1;
		 viewer[1] = 15.0;
		 viewer[2] = 0;
	     glutPostRedisplay();
         break;
      case '2':       
         viewer[0] = 1;
		 viewer[1] = 1.5;
		 viewer[2] = -3.0;
         glutPostRedisplay();
         break;
      case '3':        
		 viewer[0] = 2;
		 viewer[1] = 11;
		 viewer[2] = 10;
         glutPostRedisplay();
         break;
      case '4':    
         viewer[0] = -10;
		 viewer[1] = 1;
		 viewer[2] = 1.5;
         glutPostRedisplay();
         break;
      case '5':        
		 viewer[0] = 2;
		 viewer[1] = 12;
		 viewer[2] = -4;
         glutPostRedisplay();
         break;
      case '6':        
		 viewer[0] = 12;
		 viewer[1] = 3;
		 viewer[2] = -10;
         glutPostRedisplay();
         break;
 	  // Switch Between three lights
	  case '8':
         light = 1;
         glEnable(GL_LIGHT0);
         glDisable(GL_LIGHT1);
         glDisable(GL_LIGHT2);
         glutPostRedisplay();
		 break;
      case '9':
	     light = 2;
         glEnable(GL_LIGHT1);
         glDisable(GL_LIGHT0);
         glDisable(GL_LIGHT2);
         glutPostRedisplay();
		 break;
      case '0':
         light = 3;
         glEnable(GL_LIGHT2);
         glDisable(GL_LIGHT0);
         glDisable(GL_LIGHT1);
         glutPostRedisplay();
		 break;
       //****************************************************
      /* control viewer position */
      case 'x':                
         viewer[0] = viewer[0] + 0.4;
         glutPostRedisplay();
         break;
      case 'X':                 
         viewer[0] = viewer[0] - 0.4;
         glutPostRedisplay();
         break;
      case 'y':                
         viewer[1] = viewer[1] + 0.4;
         glutPostRedisplay();
         break;
      case 'Y':                 
         viewer[1] = viewer[1] - 0.4;
         glutPostRedisplay();
         break;
      case 'z':                
         viewer[2] = viewer[2] + 0.4;
         glutPostRedisplay();
         break;
      case 'Z':                 
         viewer[2] = viewer[2] - 0.4;
         glutPostRedisplay();
         break;
      default:
         break;
   }
}
  
void mouse(int button, int state, int x, int y)
{
	switch(button) {
	case GLUT_LEFT_BUTTON:
		  if (state == GLUT_DOWN)
		  {
			  rideLimit = 0;  
			  glutIdleFunc(raise);
		  }
		  break;
    case GLUT_MIDDLE_BUTTON:
		   if (state == GLUT_DOWN)
			    glutIdleFunc(lower);
		   break;
    case GLUT_RIGHT_BUTTON:
           if (state == GLUT_DOWN)
		   {
              if (smoothNormals) smoothNormals = false;
		        else smoothNormals = true;
		   }
		   break;
    default:
		  break;
	}

}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   
   glutInitWindowSize(1000, 800); 
   glutInitWindowPosition(0, 0);
   window1 = glutCreateWindow("GLOBAL VIEW");
   init();
   glutDisplayFunc(display); 
   glutReshapeFunc(reshape); 
   glutKeyboardFunc(keyboard);
   glutMouseFunc(mouse);
   
   
   
   glutInitWindowSize(400, 400); 
   glutInitWindowPosition(900, 0);
   window2 = glutCreateWindow("ROCKET VIEW");
   init();
   glutDisplayFunc(display); 
   glutReshapeFunc(reshape); 
   glutKeyboardFunc(keyboard);
    glutMouseFunc(mouse);
   glutMainLoop();
   
   
   return 0;
}



